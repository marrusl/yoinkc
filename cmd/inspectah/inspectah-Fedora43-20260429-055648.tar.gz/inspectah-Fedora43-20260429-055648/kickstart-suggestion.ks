# Kickstart suggestion -- review and adapt for your environment
# These settings belong at deploy time, not baked into the image.

# --- DHCP connections ---
network --bootproto=dhcp --device=enp0s5 --activate

network --hostname=Fedora43

# --- /etc/hosts additions ---
%post
echo "10.10.10.10 app.internal app" >> /etc/hosts
echo "10.10.10.11 db.internal db" >> /etc/hosts
%end

# --- Human users (deploy-time provisioning) ---
user --name=mrussell --shell=/bin/bash --homedir=/home/mrussell
user --name=appuser --shell=/bin/bash --homedir=/home/appuser
# Set passwords interactively or via --password/--iscrypted

# --- Examples ---
# network --bootproto=dhcp --device=eth0
# network --hostname=myhost.example.com
# network --bootproto=static --ip=192.168.1.10 --netmask=255.255.255.0 --gateway=192.168.1.1

# --- Remote filesystem mounts detected ---
# NFS: nfs.internal:/exports/myapp -> /mnt/myapp-nfs
#   FIXME: provide NFS credentials at deploy time
# CIFS: //files.internal/myshare -> /mnt/myapp-cifs
#   FIXME: provide CIFS credentials (username/password) at deploy time
