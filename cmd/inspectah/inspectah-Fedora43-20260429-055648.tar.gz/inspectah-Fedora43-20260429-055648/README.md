# inspectah output

Generated from **Fedora Linux 43 (Forty Three)**.

Hostname: `Fedora43`

## Findings summary

| Category | Count |
|---|---|
| Packages added (beyond base image) | 0 |
| Config files (RPM-modified) | 7 |
| Config files (unowned) | 39 |
| Services (4 enabled, 6 disabled) | 10 |
| Non-RPM software items | 16 |
| Container workloads | 3 quadlet, 1 compose |
| Secrets redacted | 1 |
| Warnings | 2 |
| FIXME items | 4 |

## Build and deploy

```bash
podman build -t my-bootc-image -f Containerfile .
```

```bash
# Custom kernel args detected -- verify they are baked into the image
# or pass them via the bootloader configuration at deploy time.
# Switch an existing system to the new image:
bootc switch my-bootc-image:latest

# Or install to a new disk:
bootc install to-disk --enforce-container-sigpolicy /dev/sdX
```

Review `kickstart-suggestion.ks` for deployment-time settings (hostname, DHCP, DNS).

## Artifacts

| File | Description |
|---|---|
| `Containerfile` | Image definition |
| `config/` | Files to COPY into the image |
| `audit-report.md` | Full findings (markdown) |
| `report.html` | Interactive report (open in browser) |
| `secrets-review.md` | Redacted items requiring manual handling |
| `kickstart-suggestion.ks` | Suggested deploy-time settings |
| `inspection-snapshot.json` | Raw data for re-rendering (`--from-snapshot`) |

## FIXME items (resolve before production)

1. FIXME: 2 user(s) with kickstart strategy — see kickstart.ks
2. FIXME: 1 custom fcontext rule(s) detected — apply in image
3. FIXME: fcontext rule contains unsafe characters: "/srv/www(/.*)?                                     all files          system_u:object_r:httpd_sys_content_t:s0"
4. FIXME: These /etc/hosts entries need to be added to the image:

## Warnings

- 1 package(s) will be downgraded by the base image — review the Version Changes section.
- readelf not available (rc=127) — ELF binary classification skipped. Install binutils in the inspectah container image.

## User Creation Strategies

bootc performs a three-way merge on `/etc` during image updates. Users baked into `/etc/passwd` in the image can conflict with runtime changes. Declarative and deploy-time approaches avoid this.

| Strategy | What it does | When to use | Risk |
|----------|-------------|-------------|------|
| **sysusers** | systemd-sysusers drop-in creates users at boot | Service accounts (nologin shell) | Users not visible until first boot |
| **useradd** | Explicit `RUN useradd` in Containerfile | Accounts needing precise control in the image | Conflicts with bootc `/etc` merge on updates |
| **kickstart** | User directives in kickstart at deploy time | Human users, site-specific accounts | Users missing if kickstart not applied |
| **blueprint** | bootc-image-builder TOML customization | When using image-builder as build pipeline | Only works with bootc-image-builder |

See [`audit-report.md`](audit-report.md) or [`report.html`](report.html) for full details.
