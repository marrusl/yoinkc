# inspectah output

Generated from **Fedora Linux 43 (Forty Three)**.

**Host:** `Fedora43`
**Inspected:** 2026-04-26T04:37:34.551938+00:00

## Findings summary

| Category | Count |
|---|---|
| Packages added (beyond base image) | 56 |
| New from base image | 142 |
| Configs modified (RPM-owned) | 0 |
| Configs unowned | 5 |
| Services changed | 7 (1 enabled, 6 disabled) |
| Secrets redacted | 3 |
| Warnings | 0 |
| FIXME items | 5 |

## Build

```bash
podman build -t my-bootc-image:latest .
```

## Deploy

```bash
# Custom kernel args detected — verify they are baked into the image
# or pass them via the bootloader configuration at deploy time.
# Switch an existing system to the new image:
bootc switch my-bootc-image:latest

# Or install to a new disk:
bootc install to-disk --enforce-container-sigpolicy /dev/sdX
```

Review `kickstart-suggestion.ks` for deployment-time settings (hostname, DHCP, DNS).

## Artifacts

| File | Description |
|---|---|
| `Containerfile` | Image definition |
| `config/` | Files to COPY into the image |
| `audit-report.md` | Full findings (markdown) |
| `report.html` | Interactive report (open in browser) |
| `secrets-review.md` | Redacted items requiring manual handling |
| `kickstart-suggestion.ks` | Suggested deploy-time settings |
| `inspection-snapshot.json` | Raw data for re-rendering (`--from-snapshot`) |

## FIXME items (resolve before production)

1. FIXME: human user 'mrussell' deferred to kickstart/provisioning
2. FIXME: 2 sudoers rule(s) — review and bake into /etc/sudoers.d/
3. FIXME: 1 SSH authorized_keys file(s) detected
4. FIXME: if these modules are needed, add them to /etc/modules-load.d/ in the image
5. FIXME: configure these interfaces via kickstart — see kickstart-suggestion.ks

## User Creation Strategies

bootc performs a three-way merge on `/etc` during image updates. Users baked into `/etc/passwd` in the image can conflict with runtime changes. Declarative and deploy-time approaches avoid this.

| Strategy | What it does | When to use | Risk |
|----------|-------------|-------------|------|
| **sysusers** | systemd-sysusers drop-in creates users at boot | Service accounts (nologin shell) | Users not visible until first boot |
| **useradd** | Explicit `RUN useradd` in Containerfile | Accounts needing precise control in the image | Conflicts with bootc `/etc` merge on updates |
| **kickstart** | User directives in kickstart at deploy time | Human users, site-specific accounts | Users missing if kickstart not applied |
| **blueprint** | bootc-image-builder TOML customization | When using image-builder as build pipeline | Only works with bootc-image-builder |

**Recommendation:** Use **sysusers** for service accounts and **kickstart** or identity management (FreeIPA, SSSD) for human users. Use `--user-strategy` to override the per-classification defaults if you want a single strategy for all users.

See [`audit-report.md`](audit-report.md) or [`report.html`](report.html) for full details.
