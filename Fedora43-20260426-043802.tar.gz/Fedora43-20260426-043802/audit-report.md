# Audit Report

**OS:** Fedora Linux 43 (Forty Three)

## Executive Summary

**213** items handled automatically &nbsp;|&nbsp; **5** items with FIXME (need review) &nbsp;|&nbsp; **4** items need manual intervention

- Packages added (beyond base image): 56
- Packages in target image only: 142
- Config files captured: 5
- Containers/quadlet found: 0
- Secrets redacted: 3

## RPM / Packages

Baseline: 525 packages from `quay.io/fedora/fedora-bootc:43`.

### Explicitly installed (16)

These packages appear in the Containerfile `dnf install` line.

#### anaconda (15)

- grubby 8.40-85.fc43.aarch64
- plymouth 24.004.60-20.fc43.aarch64
- dhcp-client 4.4.3-22.fc43.aarch64
- grub2-tools-extra 2.12-40.fc43.aarch64
- dracut-config-rescue 107-8.fc43.aarch64
- firewalld 2.3.1-5.fc43.noarch
- dnf5-plugins 5.2.17.0-2.fc43.aarch64
- sssd-kcm 2.11.1-3.fc43.aarch64
- parted 3.6-13.fc43.aarch64
- audit 4.1.1-2.fc43.aarch64
- zram-generator-defaults 1.2.1-3.fc43.noarch
- prefixdevname 0.2.0-7.fc43.aarch64
- grub2-efi-aa64-cdboot 2.12-40.fc43.aarch64
- langpacks-en 4.2-5.fc43.noarch
- rootfiles 9.0-4.fc43.noarch

#### copr:copr.fedorainfracloud.org:mrussell:inspectah (1)

- inspectah 0.1.0-1.fc43.aarch64

### In target image only (not on inspected host)
- ModemManager-glib
- NetworkManager-cloud-setup
- NetworkManager-tui
- WALinuxAgent-udev
- acl
- adcli
- adwaita-mono-fonts
- adwaita-sans-fonts
- amd-ucode-firmware
- attr
- avahi
- bind-libs
- bind-utils
- bootc
- bootupd
- bubblewrap
- bzip2
- chunkah
- cirrus-audio-firmware
- cloud-utils-growpart
- console-login-helper-messages
- console-login-helper-messages-issuegen
- console-login-helper-messages-profile
- cryptsetup
- dmidecode
- dracut-network
- dracut-squash
- ethtool
- f2fs-tools
- fedora-repos-archive
- flashrom
- flatpak-session-helper
- fstrm
- fwupd-efi
- fwupd-plugin-flashrom
- fwupd-plugin-modem-manager
- fwupd-plugin-uefi-capsule-data
- gawk-all-langpacks
- glib-networking
- glibc-minimal-langpack
- gsettings-desktop-schemas
- gssproxy
- intel-audio-firmware
- iproute-tc
- iptables-services
- iptables-utils
- irqbalance
- kdump-utils
- kexec-tools
- keyutils
- libatomic
- libdaemon
- libdnf5-plugin-expired-pgp-keys
- libev
- libftdi
- libibverbs
- libipa_hbac
- libjaylink
- libmbim
- libnfsidmap
- libpcap
- libproxy
- libqmi
- libqrtr-glib
- libsecret
- libsmbclient
- libsoup3
- libuv
- libverto-libev
- lsof
- makedumpfile
- memstrack
- mkpasswd
- nano
- nano-default-editor
- net-tools
- newt
- nfs-utils
- ngtcp2-crypto-gnutls
- nilfs-utils
- nss-altfiles
- ntfs-3g-system-compression
- numactl-libs
- nvme-cli
- openssl
- ostree
- ostree-libs
- p11-kit-server
- passim
- pciutils-libs
- pinentry
- pkcs11-provider
- polkit-pkla-compat
- python-unversioned-command
- python3-boto3
- python3-botocore
- python3-charset-normalizer
- python3-dateutil
- python3-file-magic
- python3-idna
- python3-jmespath
- python3-libdnf5
- python3-packaging
- python3-pexpect
- python3-ptyprocess
- python3-pysocks
- python3-pyyaml
- python3-requests
- python3-rpm
- python3-s3transfer
- python3-six
- python3-urllib3
- python3-urllib3+socks
- qrencode-libs
- quota
- quota-nls
- rpcbind
- rpm-ostree
- rpm-ostree-libs
- rpm-plugin-audit
- sg3_utils
- sg3_utils-libs
- skopeo
- slang
- snappy
- socat
- sos
- squashfs-tools
- sssd-ad
- sssd-common-pac
- sssd-ipa
- sssd-krb5
- sssd-ldap
- sssd-nfs-idmap
- stalld
- sudo-python-plugin
- toolbox
- tpm2-tools
- tpm2-tss-fapi
- udftools
- wcurl
- whois-nls

### Version Changes

**173 upgrade(s)** — base image has newer version than host:

- NetworkManager (aarch64): 1.54.0-2.fc43 → 1.54.3-2.fc43
- NetworkManager-libnm (aarch64): 1.54.0-2.fc43 → 1.54.3-2.fc43
- alternatives (aarch64): 1.33-2.fc43 → 1.33-3.fc43
- amd-gpu-firmware (noarch): 20251021-1.fc43 → 20260410-1.fc43
- atheros-firmware (noarch): 20251021-1.fc43 → 20260410-1.fc43
- audit-libs (aarch64): 4.1.1-2.fc43 → 4.1.4-1.fc43
- bluez (aarch64): 5.84-2.fc43 → 5.86-4.fc43
- brcmfmac-firmware (noarch): 20251021-1.fc43 → 20260410-1.fc43
- btrfs-progs (aarch64): 6.17-1.fc43 → 6.19.1-1.fc43
- ca-certificates (noarch): 2025.2.80_v9.0.304-1.1.fc43 → 2025.2.80_v9.0.304-1.2.fc43
- chrony (aarch64): 4.8-1.fc43 → 4.8-3.fc43
- container-selinux (noarch): 2.242.0-1.fc43 → 2.247.0-1.fc43
- coreutils (aarch64): 9.7-6.fc43 → 9.7-8.fc43
- coreutils-common (aarch64): 9.7-6.fc43 → 9.7-8.fc43
- crypto-policies (noarch): 20250714-5.gitcd6043a.fc43 → 20251125-1.git63291f8.fc43
- crypto-policies-scripts (noarch): 20250714-5.gitcd6043a.fc43 → 20251125-1.git63291f8.fc43
- cryptsetup-libs (aarch64): 2.8.1-1.fc43 → 2.8.4-1.fc43
- curl (aarch64): 8.15.0-2.fc43 → 8.15.0-6.fc43
- dnf5 (aarch64): 5.2.17.0-2.fc43 → 5.2.18.0-3.fc43
- elfutils-debuginfod-client (aarch64): 0.193-3.fc43 → 0.194-1.fc43
- elfutils-default-yama-scope (noarch): 0.193-3.fc43 → 0.194-1.fc43
- elfutils-libelf (aarch64): 0.193-3.fc43 → 0.194-1.fc43
- elfutils-libs (aarch64): 0.193-3.fc43 → 0.194-1.fc43
- exfatprogs (aarch64): 1.2.9-2.fc43 → 1.3.2-1.fc43
- expat (aarch64): 2.7.2-1.fc43 → 2.7.3-1.fc43
- fedora-release (noarch): 43-25 → 43-27
- fedora-release-common (noarch): 43-25 → 43-27
- fedora-release-identity-basic (noarch): 43-25 → 43-27
- file (aarch64): 5.46-8.fc43 → 5.46-9.fc43
- file-libs (aarch64): 5.46-8.fc43 → 5.46-9.fc43
- fuse3 (aarch64): 3.16.2-5.fc42 → 3.16.2-6.fc43
- fuse3-libs (aarch64): 3.16.2-5.fc42 → 3.16.2-6.fc43
- fwupd (aarch64): 2.0.16-1.fc43 → 2.0.20-1.fc43
- glib2 (aarch64): 2.86.0-2.fc43 → 2.86.5-1.fc43
- glibc (aarch64): 2.42-4.fc43 → 2.42-11.fc43
- glibc-common (aarch64): 2.42-4.fc43 → 2.42-11.fc43
- glibc-gconv-extra (aarch64): 2.42-4.fc43 → 2.42-11.fc43
- gnupg2 (aarch64): 2.4.8-4.fc43 → 2.4.9-5.fc43
- gnupg2-dirmngr (aarch64): 2.4.8-4.fc43 → 2.4.9-5.fc43
- gnupg2-gpg-agent (aarch64): 2.4.8-4.fc43 → 2.4.9-5.fc43
- gnupg2-gpgconf (aarch64): 2.4.8-4.fc43 → 2.4.9-5.fc43
- gnupg2-keyboxd (aarch64): 2.4.8-4.fc43 → 2.4.9-5.fc43
- gnupg2-verify (aarch64): 2.4.8-4.fc43 → 2.4.9-5.fc43
- gnutls (aarch64): 3.8.10-3.fc43 → 3.8.12-1.fc43
- groff-base (aarch64): 1.23.0-10.fc43 → 1.23.0-11.fc43
- grub2-common (noarch): 2.12-40.fc43 → 2.12-43.fc43
- grub2-efi-aa64 (aarch64): 2.12-40.fc43 → 2.12-43.fc43
- grub2-tools (aarch64): 2.12-40.fc43 → 2.12-43.fc43
- grub2-tools-minimal (aarch64): 2.12-40.fc43 → 2.12-43.fc43
- hwdata (noarch): 0.399-1.fc43 → 0.406-1.fc43
- intel-gpu-firmware (noarch): 20251021-1.fc43 → 20260410-1.fc43
- iptables-libs (aarch64): 1.8.11-11.fc43 → 1.8.11-12.fc43
- iptables-nft (aarch64): 1.8.11-11.fc43 → 1.8.11-12.fc43
- jq (aarch64): 1.7.1-12.fc43 → 1.8.1-3.fc43
- json-glib (aarch64): 1.10.8-1.fc43 → 1.10.8-4.fc43
- kernel (aarch64): 6.17.1-300.fc43 → 6.19.13-200.fc43
- kernel-core (aarch64): 6.17.1-300.fc43 → 6.19.13-200.fc43
- kernel-modules (aarch64): 6.17.1-300.fc43 → 6.19.13-200.fc43
- kernel-modules-core (aarch64): 6.17.1-300.fc43 → 6.19.13-200.fc43
- krb5-libs (aarch64): 1.21.3-7.fc43 → 1.22.2-3.fc43
- less (aarch64): 679-2.fc43 → 685-1.fc43
- libarchive (aarch64): 3.8.1-3.fc43 → 3.8.4-1.fc43
- libblkid (aarch64): 2.41.1-17.fc43 → 2.41.4-7.fc43
- libbrotli (aarch64): 1.1.0-10.fc43 → 1.2.0-1.fc43
- libbytesize (aarch64): 2.11-104.fc43 → 2.12-1.fc43
- libcap (aarch64): 2.76-3.fc43 → 2.76-4.fc43
- libcap-ng (aarch64): 0.8.5-8.fc43 → 0.9.3-1.fc43
- libcurl (aarch64): 8.15.0-2.fc43 → 8.15.0-6.fc43
- libdnf5 (aarch64): 5.2.17.0-2.fc43 → 5.2.18.0-3.fc43
- libdnf5-cli (aarch64): 5.2.17.0-2.fc43 → 5.2.18.0-3.fc43
- libdrm (aarch64): 2.4.125-2.fc43 → 2.4.131-1.fc43
- libedit (aarch64): 3.1-56.20250104cvs.fc43 → 3.1-57.20251016cvs.fc43
- libfdisk (aarch64): 2.41.1-17.fc43 → 2.41.4-7.fc43
- libffi (aarch64): 3.5.1-2.fc43 → 3.5.2-1.fc43
- libgcc (aarch64): 15.2.1-2.fc43 → 15.2.1-7.fc43
- libgcrypt (aarch64): 1.11.1-2.fc43 → 1.11.1-3.fc43
- libgomp (aarch64): 15.2.1-2.fc43 → 15.2.1-7.fc43
- libjcat (aarch64): 0.2.5-1.fc43 → 0.2.6-1.fc43
- liblastlog2 (aarch64): 2.41.1-17.fc43 → 2.41.4-7.fc43
- libldb (aarch64): 4.23.1-1.fc43 → 4.23.5-2.fc43
- libmaxminddb (aarch64): 1.12.2-4.fc43 → 1.13.3-1.fc43
- libmount (aarch64): 2.41.1-17.fc43 → 2.41.4-7.fc43
- libnetfilter_conntrack (aarch64): 1.0.9-9.fc43 → 1.1.1-1.fc43
- libnl3 (aarch64): 3.11.0-6.fc43 → 3.12.0-2.fc43
- libnvme (aarch64): 1.15-4.fc43 → 1.16.1-1.fc43
- libsmartcols (aarch64): 2.41.1-17.fc43 → 2.41.4-7.fc43
- libsolv (aarch64): 0.7.34-5.fc43 → 0.7.36-2.fc43
- libssh (aarch64): 0.11.3-1.fc43 → 0.11.4-1.fc43
- libssh-config (noarch): 0.11.3-1.fc43 → 0.11.4-1.fc43
- libsss_certmap (aarch64): 2.11.1-3.fc43 → 2.12.0-1.fc43
- libsss_idmap (aarch64): 2.11.1-3.fc43 → 2.12.0-1.fc43
- libsss_nss_idmap (aarch64): 2.11.1-3.fc43 → 2.12.0-1.fc43
- libsss_sudo (aarch64): 2.11.1-3.fc43 → 2.12.0-1.fc43
- libstdc++ (aarch64): 15.2.1-2.fc43 → 15.2.1-7.fc43
- libtasn1 (aarch64): 4.20.0-2.fc43 → 4.21.0-1.fc43
- libtirpc (aarch64): 1.3.7-0.fc43 → 1.3.7-1.fc43
- libtool-ltdl (aarch64): 2.5.4-7.fc43 → 2.5.4-8.fc43
- libudisks2 (aarch64): 2.10.91-1.fc43 → 2.11.1-1.fc43
- libuuid (aarch64): 2.41.1-17.fc43 → 2.41.4-7.fc43
- libwbclient (aarch64): 4.23.1-1.fc43 → 4.23.5-2.fc43
- libxcrypt (aarch64): 4.4.38-8.fc43 → 4.5.2-1.fc43
- libxmlb (aarch64): 0.3.24-1.fc43 → 0.3.26-1.fc43
- linux-firmware (noarch): 20251021-1.fc43 → 20260410-1.fc43
- linux-firmware-whence (noarch): 20251021-1.fc43 → 20260410-1.fc43
- lmdb-libs (aarch64): 0.9.33-4.fc43 → 0.9.34-1.fc43
- lua-libs (aarch64): 5.4.8-2.fc43 → 5.4.8-4.fc43
- mt7xxx-firmware (noarch): 20251021-1.fc43 → 20260410-1.fc43
- nftables (aarch64): 1.1.3-5.fc43 → 1.1.3-6.fc43.1
- nftables-services (noarch): 1.1.3-5.fc43 → 1.1.3-6.fc43.1
- ngtcp2 (aarch64): 1.15.1-1.fc43 → 1.21.0-1.fc43
- nspr (aarch64): 4.37.0-3.fc43 → 4.38.2-4.fc43
- nss (aarch64): 3.115.1-1.fc43 → 3.121.0-1.fc43
- nss-softokn (aarch64): 3.115.1-1.fc43 → 3.121.0-1.fc43
- nss-softokn-freebl (aarch64): 3.115.1-1.fc43 → 3.121.0-1.fc43
- nss-sysinit (aarch64): 3.115.1-1.fc43 → 3.121.0-1.fc43
- nss-util (aarch64): 3.115.1-1.fc43 → 3.121.0-1.fc43
- nvidia-gpu-firmware (noarch): 20251021-1.fc43 → 20260410-1.fc43
- nxpwireless-firmware (noarch): 20251021-1.fc43 → 20260410-1.fc43
- openldap (aarch64): 2.6.10-4.fc43 → 2.6.13-1.fc43
- openssh (aarch64): 10.0p1-5.fc43 → 10.0p1-8.fc43
- openssh-clients (aarch64): 10.0p1-5.fc43 → 10.0p1-8.fc43
- openssh-server (aarch64): 10.0p1-5.fc43 → 10.0p1-8.fc43
- openssl-libs (aarch64): 3.5.1-2.fc43 → 3.5.4-2.fc43
- p11-kit (aarch64): 0.25.8-1.fc43 → 0.26.2-1.fc43
- p11-kit-trust (aarch64): 0.25.8-1.fc43 → 0.26.2-1.fc43
- pam (aarch64): 1.7.1-3.fc43 → 1.7.1-4.fc43
- pam-libs (aarch64): 1.7.1-3.fc43 → 1.7.1-4.fc43
- passim-libs (aarch64): 0.1.10-2.fc43 → 0.1.11-1.fc43
- pcre2 (aarch64): 10.46-1.fc43 → 10.47-1.fc43
- pcre2-syntax (noarch): 10.46-1.fc43 → 10.47-1.fc43
- policycoreutils (aarch64): 3.9-5.fc43 → 3.9-7.fc43
- polkit (aarch64): 126-6.fc43 → 126-6.fc43.2
- polkit-libs (aarch64): 126-6.fc43 → 126-6.fc43.2
- procps-ng (aarch64): 4.0.4-7.fc43 → 4.0.4-7.fc43.1
- protobuf-c (aarch64): 1.5.1-2.fc43 → 1.5.2-1.fc43
- publicsuffix-list-dafsa (noarch): 20250616-2.fc43 → 20260116-1.fc43
- python3 (aarch64): 3.14.0-1.fc43 → 3.14.4-1.fc43
- python3-libs (aarch64): 3.14.0-1.fc43 → 3.14.4-1.fc43
- qcom-wwan-firmware (noarch): 20251021-1.fc43 → 20260410-1.fc43
- realtek-firmware (noarch): 20251021-1.fc43 → 20260410-1.fc43
- rpm (aarch64): 6.0.0-1.fc43 → 6.0.1-1.fc43
- rpm-build-libs (aarch64): 6.0.0-1.fc43 → 6.0.1-1.fc43
- rpm-libs (aarch64): 6.0.0-1.fc43 → 6.0.1-1.fc43
- rpm-plugin-selinux (aarch64): 6.0.0-1.fc43 → 6.0.1-1.fc43
- rpm-sequoia (aarch64): 1.9.0-2.fc43 → 1.10.1-1.fc43
- rpm-sign-libs (aarch64): 6.0.0-1.fc43 → 6.0.1-1.fc43
- samba-client-libs (aarch64): 4.23.1-1.fc43 → 4.23.5-2.fc43
- samba-common (noarch): 4.23.1-1.fc43 → 4.23.5-2.fc43
- samba-common-libs (aarch64): 4.23.1-1.fc43 → 4.23.5-2.fc43
- selinux-policy (noarch): 42.12-1.fc43 → 43.6-1.fc43
- selinux-policy-targeted (noarch): 42.12-1.fc43 → 43.6-1.fc43
- sssd-client (aarch64): 2.11.1-3.fc43 → 2.12.0-1.fc43
- sssd-common (aarch64): 2.11.1-3.fc43 → 2.12.0-1.fc43
- sssd-krb5-common (aarch64): 2.11.1-3.fc43 → 2.12.0-1.fc43
- sudo (aarch64): 1.9.17-5.p1.fc43 → 1.9.17-7.p2.fc43
- systemd (aarch64): 258-1.fc43 → 258.7-1.fc43
- systemd-libs (aarch64): 258-1.fc43 → 258.7-1.fc43
- systemd-pam (aarch64): 258-1.fc43 → 258.7-1.fc43
- systemd-resolved (aarch64): 258-1.fc43 → 258.7-1.fc43
- systemd-shared (aarch64): 258-1.fc43 → 258.7-1.fc43
- systemd-sysusers (aarch64): 258-1.fc43 → 258.7-1.fc43
- systemd-udev (aarch64): 258-1.fc43 → 258.7-1.fc43
- tiwilink-firmware (noarch): 20251021-1.fc43 → 20260410-1.fc43
- tzdata (noarch): 2025b-3.fc43 → 2026a-1.fc43
- udisks2 (aarch64): 2.10.91-1.fc43 → 2.11.1-1.fc43
- util-linux (aarch64): 2.41.1-17.fc43 → 2.41.4-7.fc43
- util-linux-core (aarch64): 2.41.1-17.fc43 → 2.41.4-7.fc43
- vim-data (noarch): 9.1.1818-1.fc43 → 9.2.280-1.fc43
- vim-minimal (aarch64): 9.1.1818-1.fc43 → 9.2.280-1.fc43
- xkeyboard-config (noarch): 2.45-1.fc43 → 2.46-1.fc43
- xz (aarch64): 5.8.1-2.fc43 → 5.8.1-4.fc43
- xz-libs (aarch64): 5.8.1-2.fc43 → 5.8.1-4.fc43
- zlib-ng-compat (aarch64): 2.2.5-2.fc43 → 2.3.3-2.fc43

## Services

| Unit | Current | Default | Action |
|------|---------|---------|--------|
| lvm-devices-import.service | disabled | enabled | disable |
| systemd-homed-activate.service | disabled | enabled | disable |
| systemd-homed.service | disabled | enabled | disable |
| systemd-network-generator.service | disabled | enabled | disable |
| systemd-oomd.service | disabled | enabled | disable |
| systemd-pstore.service | disabled | enabled | disable |
| dnf-makecache.timer | enabled | disabled | enable |

## Configuration Files

- RPM-owned modified: 0
- Unowned: 5
- `/etc/NetworkManager/system-connections/enp0s5.nmconnection` (unowned)
- `/etc/firewalld/zones/public.xml` (unowned)
- `/etc/ssh/sshd_config.d/01-permitrootlogin.conf` (unowned)
- `/etc/systemd/system/dbus-org.freedesktop.resolve1.service` (unowned)
- `/etc/yum.repos.d/_copr:copr.fedorainfracloud.org:mrussell:inspectah.repo` (unowned)

## Network

### Connections

**DHCP (kickstart at deploy time):**
- `enp0s5` — ethernet — `etc/NetworkManager/system-connections/enp0s5.nmconnection`

### Firewall zones (bake into image)

**public:** services=ssh, mdns, dhcpv6-client | ports=— | rich rules=0

#### Alternative: firewall-offline-cmd (instead of COPY)

```dockerfile
RUN firewall-offline-cmd --zone=public --add-service=ssh
RUN firewall-offline-cmd --zone=public --add-service=mdns
RUN firewall-offline-cmd --zone=public --add-service=dhcpv6-client
```

### DNS — resolv.conf provenance: **systemd-resolved**

### Static routes (from `ip route`)

- `default via 10.88.0.1 dev eth0 proto static metric 100`

## Storage Migration Plan

Each mount point below should be mapped to one of:
- **Image-embedded** — small, static data seeded at initial bootstrap
- **PVC / volume mount** — application data, databases
- **External storage** — NFS/CIFS shared filesystems

| Device | Mount Point | FS Type | Recommendation |
|--------|-------------|---------|----------------|
| `UUID=3d68b415-19ee-4889-9307-57c3f25b3dc8` | `/` | xfs | image-embedded (managed by bootc) |
| `UUID=b0a6854d-f986-4ce8-8773-99023af2b344` | `/boot` | xfs | image-embedded (managed by bootc) |
| `UUID=5D12-6369` | `/boot/efi` | vfat | image-embedded (managed by bootc) |

## Scheduled tasks

- 14 vendor timer(s) from the base image are present and will carry over automatically.

## Kernel and boot

- cmdline: `BOOT_IMAGE=(hd0,gpt2)/vmlinuz-6.17.1-300.fc43.aarch64 root=/dev/mapper/fedora_fedora43-root ro rd.lvm.lv=fedora_fedora43/root rhgb quiet`
- GRUB defaults present

- 27 kernel module(s) loaded at inspection time (hardware-specific, not included in the image). See modules-load.d entries below for explicitly configured modules.

### Non-default sysctl values (1)

| Key | Runtime | Default | Source |
|-----|---------|---------|--------|
| `net.core.optmem_max` | **131072** | 81920 | `usr/lib/sysctl.d/50-libkcapi-optmem_max.conf` |
- modprobe.d: `etc/modprobe.d/firewalld-sysctls.conf`

## SELinux / Security

- SELinux mode: enforcing

## Users and groups

- User: **mrussell** (uid 1000, home `/home/mrussell`, shell `/bin/bash`)
- Group: **mrussell** (gid 1000)

### Sudoers rules
- `root	ALL=(ALL) 	ALL`
- `%wheel	ALL=(ALL)	ALL`

### SSH authorized_keys (flagged for manual handling)
- User **mrussell**: `/home/mrussell/.ssh/authorized_keys`

### User Migration Strategy

| User | UID | Type | Strategy | Notes |
|------|-----|------|----------|-------|
| mrussell | 1000 | human | kickstart | SSH keys, has password |

**Strategies:** sysusers = systemd-sysusers drop-in (boot-time), useradd = explicit RUN in Containerfile, kickstart = deferred to deploy-time provisioning, blueprint = bootc-image-builder TOML

## Data Migration Plan (/var)

Content under `/var` is seeded at initial bootstrap and **not updated** by subsequent bootc deployments.
`tmpfiles.d` snippets ensure expected directories exist on every boot.
Review application data under `/var/lib`, `/var/log`, `/var/data` for separate migration strategies.

| Directory | Size | Recommendation |
|-----------|------|----------------|
| `/var/lib/chrony` | 42 bytes | PVC / volume mount — application data, review application needs |
| `/var/lib/containers` | Over 10 MB | PVC / volume mount — container storage |
| `/var/lib/lastlog` | ~12 KB | PVC / volume mount — application data, review application needs |
| `/var/log/anaconda` | ~5 MB | PVC / volume mount — log retention (or ship to external logging) |
| `/var/log/audit` | ~87 KB | PVC / volume mount — log retention (or ship to external logging) |
| `/var/log/journal` | Over 10 MB | PVC / volume mount — log retention (or ship to external logging) |

## Environment-specific considerations

**Note:** bootc uses a 3-way merge strategy for `/etc` during image updates. Local changes to `/etc` persist across updates, but the merge behavior has nuances — see the [bootc filesystem documentation](https://containers.github.io/bootc/filesystem.html) for details.

## Package Details

### Dependencies (40)

These packages are pulled in automatically by dnf. If the target image produces a different dependency set, promote packages from this list to the `dnf install` line.

- hunspell-filesystem 1.7.2-10.fc43.aarch64
- google-noto-fonts-common 20250901-1.fc43.noarch
- hunspell-en-US 0.20201207-12.fc43.noarch
- google-noto-sans-mono-vf-fonts 20250901-1.fc43.noarch
- google-noto-serif-vf-fonts 20250901-1.fc43.noarch
- google-noto-sans-vf-fonts 20250901-1.fc43.noarch
- hunspell-en-GB 0.20201207-12.fc43.noarch
- abattis-cantarell-vf-fonts 0.301-15.fc43.noarch
- default-fonts-core-sans 4.2-5.fc43.noarch
- langpacks-core-en 4.2-5.fc43.noarch
- langpacks-fonts-en 4.2-5.fc43.noarch
- vim-filesystem 9.1.1818-1.fc43.noarch
- glibc-langpack-en 2.42-4.fc43.aarch64
- gobject-introspection 1.84.0-3.fc43.aarch64
- audit-rules 4.1.1-2.fc43.aarch64
- which 2.23-3.fc43.aarch64
- graphite2 1.3.14-19.fc43.aarch64
- libpng 1.6.50-2.fc43.aarch64
- harfbuzz 11.5.1-1.fc43.aarch64
- freetype 2.13.3-3.fc43.aarch64
- mtools 4.0.49-2.fc43.aarch64
- ipcalc 1.0.3-12.fc43.aarch64
- libevdev 1.13.4-2.fc43.aarch64
- plymouth-core-libs 24.004.60-20.fc43.aarch64
- python3-dbus 1.4.0-7.fc43.aarch64
- python3-gobject-base 3.54.3-1.fc43.aarch64
- python3-nftables 1.1.3-5.fc43.noarch
- python3-firewall 2.3.1-5.fc43.noarch
- gpm-libs 1.20.7-52.fc43.aarch64
- libsodium 1.0.20-6.fc43.aarch64
- xxd 9.1.1818-1.fc43.aarch64
- vim-common 9.1.1818-1.fc43.aarch64
- vim-enhanced 9.1.1818-1.fc43.aarch64
- firewalld-filesystem 2.3.1-5.fc43.noarch
- plymouth-scripts 24.004.60-20.fc43.aarch64
- dhcp-common 4.4.3-22.fc43.noarch
- initscripts-service 10.26-4.fc43.noarch
- vim-default-editor 9.1.1818-1.fc43.noarch
- hunspell 1.7.2-10.fc43.aarch64
- hunspell-en 0.20201207-12.fc43.noarch

### Package Dependency Tree (56 packages beyond base image)

**16 leaf packages** → 40 dependencies

**langpacks-en** (8 deps)
  ├── abattis-cantarell-vf-fonts
  ├── default-fonts-core-sans
  ├── google-noto-fonts-common
  ├── google-noto-sans-mono-vf-fonts
  ├── google-noto-sans-vf-fonts
  ├── google-noto-serif-vf-fonts
  ├── langpacks-core-en
  └── langpacks-fonts-en

**firewalld** (6 deps)
  ├── firewalld-filesystem
  ├── gobject-introspection
  ├── python3-dbus
  ├── python3-firewall
  ├── python3-gobject-base
  └── python3-nftables

**grub2-tools-extra** (5 deps)
  ├── freetype
  ├── graphite2
  ├── harfbuzz
  ├── libpng
  └── mtools

**plymouth** (3 deps)
  ├── libevdev
  ├── plymouth-core-libs
  └── plymouth-scripts

**dhcp-client** (2 deps)
  ├── dhcp-common
  └── ipcalc

**audit** (1 deps)
  └── audit-rules

**dnf5-plugins** (0 deps — installed independently)

**dracut-config-rescue** (0 deps — installed independently)

**grub2-efi-aa64-cdboot** (0 deps — installed independently)

**grubby** (0 deps — installed independently)

**inspectah** (0 deps — installed independently)

**parted** (0 deps — installed independently)

**prefixdevname** (0 deps — installed independently)

**rootfiles** (0 deps — installed independently)

**sssd-kcm** (0 deps — installed independently)

**zram-generator-defaults** (0 deps — installed independently)


## Redactions (secrets)

- **users:shadow/mrussell**: SHADOW_HASH — value-removed
- **/etc/systemd/system/dbus-org.freedesktop.resolve1.service**: Documentation — value-removed
- **/etc/systemd/system/dbus-org.freedesktop.resolve1.service**: Documentation — value-removed
