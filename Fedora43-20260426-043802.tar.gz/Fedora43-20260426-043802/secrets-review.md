# Secrets Review

> Detected secrets: 3 redacted (1 pattern, 2 heuristic)

The following items were redacted or excluded. Handle them according to
the action specified for each item.

## Inline Redactions

| Path | Line | Type | Placeholder | Detection | Action |
|------|------|------|-------------|-----------|--------|
| users:shadow/mrussell | — | SHADOW_HASH | REDACTED_SHADOW_HASH_1 | pattern | Supply value at deploy time |
| /etc/systemd/system/dbus-org.freedesktop.resolve1.service | 14 | Documentation | REDACTED_DOCUMENTATION_1 | heuristic (high) | Supply value at deploy time |
| /etc/systemd/system/dbus-org.freedesktop.resolve1.service | 15 | Documentation | REDACTED_DOCUMENTATION_2 | heuristic (high) | Supply value at deploy time |
