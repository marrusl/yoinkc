# Kickstart suggestion -- review and adapt for your environment
# These settings belong at deploy time, not baked into the image.

# --- DHCP connections ---
network --bootproto=dhcp --device=enp0s5 --activate

network --hostname=Fedora43

# --- Human users (deploy-time provisioning) ---
user --name=mrussell --shell=/bin/bash --homedir=/home/mrussell
# Set passwords interactively or via --password/--iscrypted

# --- Examples ---
# network --bootproto=dhcp --device=eth0
# network --hostname=myhost.example.com
# network --bootproto=static --ip=192.168.1.10 --netmask=255.255.255.0 --gateway=192.168.1.1
