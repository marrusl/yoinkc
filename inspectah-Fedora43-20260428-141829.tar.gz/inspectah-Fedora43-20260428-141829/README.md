# inspectah output

Generated from **Fedora Linux 43 (Forty Three)**.

Hostname: `Fedora43`

## Findings summary

| Category | Count |
|---|---|
| Packages (all -- no baseline) | 0 |
| Config files (unowned) | 7 |
| Services (0 enabled, 5 disabled) | 5 |
| Non-RPM software items | 2 |
| Secrets redacted | 1 |
| Warnings | 2 |
| FIXME items | 1 |

## Build and deploy

```bash
podman build -t my-bootc-image -f Containerfile .
```

```bash
# Custom kernel args detected -- verify they are baked into the image
# or pass them via the bootloader configuration at deploy time.
# Switch an existing system to the new image:
bootc switch my-bootc-image:latest

# Or install to a new disk:
bootc install to-disk --enforce-container-sigpolicy /dev/sdX
```

Review `kickstart-suggestion.ks` for deployment-time settings (hostname, DHCP, DNS).

## Artifacts

| File | Description |
|---|---|
| `Containerfile` | Image definition |
| `config/` | Files to COPY into the image |
| `audit-report.md` | Full findings (markdown) |
| `report.html` | Interactive report (open in browser) |
| `secrets-review.md` | Redacted items requiring manual handling |
| `kickstart-suggestion.ks` | Suggested deploy-time settings |
| `inspection-snapshot.json` | Raw data for re-rendering (`--from-snapshot`) |

## FIXME items (resolve before production)

1. FIXME: 1 user(s) with kickstart strategy — see kickstart.ks

## Warnings

- No base image service presets available — service state changes are reported without comparison to base image defaults. All non-default-enabled units will appear as changes.
- readelf not available (rc=127) — ELF binary classification skipped. Install binutils in the inspectah container image.

## User Creation Strategies

bootc performs a three-way merge on `/etc` during image updates. Users baked into `/etc/passwd` in the image can conflict with runtime changes. Declarative and deploy-time approaches avoid this.

| Strategy | What it does | When to use | Risk |
|----------|-------------|-------------|------|
| **sysusers** | systemd-sysusers drop-in creates users at boot | Service accounts (nologin shell) | Users not visible until first boot |
| **useradd** | Explicit `RUN useradd` in Containerfile | Accounts needing precise control in the image | Conflicts with bootc `/etc` merge on updates |
| **kickstart** | User directives in kickstart at deploy time | Human users, site-specific accounts | Users missing if kickstart not applied |
| **blueprint** | bootc-image-builder TOML customization | When using image-builder as build pipeline | Only works with bootc-image-builder |

See [`audit-report.md`](audit-report.md) or [`report.html`](report.html) for full details.
