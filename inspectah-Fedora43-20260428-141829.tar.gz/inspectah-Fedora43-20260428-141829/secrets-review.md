# Secrets Review

> Detected secrets: 1 redacted (1 inline)

The following items were redacted or excluded. Handle them according to
the action specified for each item.

## Inline Redactions

Secret values in these files/entries were replaced with `[REDACTED-*]` tokens.

| Path | Line | Pattern | Detection |
|------|------|---------|-----------|
| /etc/shadow | -- | PASSWORD_HASH | pattern |
